===============================================================================
GAMBLE INC. - PRESS KIT SUMMARY
===============================================================================

-------------------------------------------------------------------------------
1. FACT SHEET
-------------------------------------------------------------------------------
Developer:          Digital Umami [FILL IN IF OTHER / CO-DEVELOPER]
Publisher:          Digital Umami [FILL IN IF APPLICABLE]
Release Date:       [FILL IN: e.g., Q4 2026 / TBA / Wishlist Now]
Platforms:          PC (Steam) [FILL IN: Other platforms if applicable]
Website:            https://digitalumami.github.io/gmbl.html
Steam Store Page:   https://store.steampowered.com/app/4632620/Gamble_Inc/
Price:              [FILL IN: e.g., $X.YY / TBD]
ESRB / Rating:      [FILL IN: e.g., Rating Pending / Teen / Mature]
Contact / Press:    [FILL IN: Contact Email, e.g. press@digitalumami.com]
Socials:            [FILL IN: Twitter/X, Discord, YouTube links]

-------------------------------------------------------------------------------
2. GAME OVERVIEW
-------------------------------------------------------------------------------
Tired of making money for your corporate overlords while you get paid peanuts? 
Hack into your work computer and syphon cash straight from the slots and into 
your bank! In this corporate dystopia, jobs have been reduced to betting all 
you've got and letting the house (your boss) win. Now Hiring!

-------------------------------------------------------------------------------
3. KEY FEATURES
-------------------------------------------------------------------------------
• Corporate Dystopia Setting: Work in a high-stakes dystopian office environment 
  where employment and gambling merge.
• Hack & Syphon Cash: Infiltrate your workstation to extract money straight 
  from slot mechanics into your personal account.
• High-Stakes Risk/Reward: Turn the tables on your boss and outsmart "the house".
• [FILL IN: Feature 4 - e.g., Unique minigames or deck-building mechanics]
• [FILL IN: Feature 5 - e.g., Soundtracks, visual art style, or narrative elements]

-------------------------------------------------------------------------------
4. LOGLINE / TAGLINE
-------------------------------------------------------------------------------
"Hack the system, beat the house, and take back what's yours in a corporate dystopia."

-------------------------------------------------------------------------------
5. ASSETS & MEDIA LINKS
-------------------------------------------------------------------------------
High-Res Screenshots & Logos: [FILL IN: Link to Google Drive / Dropbox / Zip file]
Official Trailer:             [FILL IN: YouTube Embed/Watch link]
Key Art & Promotional Images: [FILL IN: Link or relative file path]

-------------------------------------------------------------------------------
6. ABOUT DIGITAL UMAMI
-------------------------------------------------------------------------------
[FILL IN: Brief paragraph about your indie studio background, mission, or history.]
